
var agent = navigator.userAgent;

if(agent.search(/Android/) != -1 || agent.search(/iPad/) != -1 || agent.search(/iPhone/) != -1 || agent.search(/iPod/) != -1){
    monaca.viewport({width : 1024});
}

jQuery(document).ready(function(){
    var Pos = $('#detailName').height();
    var newPos = Pos+120;
	
    if(agent.search(/Android/) != -1){
		if(Pos!=null){
        	$('#back').css('position','absolute');
			$('#back').css('left',12);
			$('#back').css('top',newPos);
        	$('#Footer').css('padding','10px 0');
        	$('body').append('<div id="closeBtn"><img src="img/close.gif"></div>');
		}
        /*$('.cateInfo dl dd,.Movie').css('display','none');*/
    }
    if(agent.search(/iPad/) != -1 || agent.search(/iPhone/) != -1 || agent.search(/iPod/) != -1){
        $('#contHanger').css('min-height',400);
    }
    if ($('#detailName img')[0]) {
		$('#detailImage img').click(function(){
		 	$('#zoomHanger').css('display','block');
            $('#closeBtn').css('display','block');
		});
		$('#zoomHanger,#closeBtn').click(function(){
			$('#zoomHanger').css('display','none');
            $('#closeBtn').css('display','none');
		});
	}
	/*$('.Hanger dl').click(function(){
        var ID = $(this).attr('id');
        location.href = ID;
    })*/
	$('#fig01').css('display','block');
	$('#01').addClass('selected');
    $('#Tab li a').click(function(){
	    var ID = $(this).attr('id');
		var Target = '#fig'+ID;
		$('#Tab li a').removeClass('selected');
        $(this).addClass('selected');
		$('.figHanger').css('display','none');
		$(Target).css('display','block');
		return false
	});
});

$(window).load(function() {
    var w = $(window).width();
    var h = $(window).height();
	var h2 = $('.flickableControl').height();
	var h3 = $('#Footer').height();
	var bodyH = $('body').height();
    /*if(agent.search(/Android/) != -1){
	    if(bodyH < h){
            var newH = h-(h2+h3+207);
		    $('#contHanger').css('height',newH);
	    }
    }*/
    if(agent.search(/iPad/) != -1 || agent.search(/iPhone/) != -1 || agent.search(/iPod/) != -1){
        if(bodyH < h-3){
            var newH = h-bodyH;
            $('#Footer').css('height',newH-33);
	    }
    }
});
