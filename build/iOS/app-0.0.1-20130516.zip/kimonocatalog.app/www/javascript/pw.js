
var PS = "kimono";
var keyWord;

jQuery(document).ready(function(){
	/*localStorage.clear();*/
	checkLocalStorage();
	if(keyWord!=PS){
		createlayer();
		$('.Btn').click(function(){
			var N = $('#pw').attr('value');
			if(N==PS){
				$('#overLayer,#passWord').css('display','none');
				localStorage.setItem('password', PS);
			}else{
				$('.Alert').css('padding','5px 10px');
				$('.Alert').html('パスワードが間違っています。<br>パスワードをご確認の上もう一度<br>ご入力下さい。');
			}
		});
	}
});

function checkLocalStorage(){
	keyWord = localStorage.getItem('password');
}